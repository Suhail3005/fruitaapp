#!/bin/bash

echo "Removing the app.."
echo "Removing the fruitapp-backend"
docker stop fruitapp-backend && docker rm -f fruitapp-backend
echo ""
echo "removing the fruitapp-web container"
docker stop fruitapp-frontend && docker rm -f fruitapp-frontend

echo ""
echo "removing the fruitapp-db container"
docker stop fruitapp-db && docker rm -f fruitapp-db

echo "App removed."
