# Overview of the APP

The application consist of two parts, an API and a front end. The application displays 5 fruits which are seeded to the database at the startup. The get API provides the list of fruits. Anyone can like a fruit. In this case the count of like will be increased.

![homepage](images/homepage.png?raw=true "System Architecture")

# Requirements

The basic system requirements are as follows

- Any OS, preferably Linux
- Docker
- Docker compose

# Architecture

![Architecture](images/fruitapp.jpg?raw=true "System Architecture")

### Technology used

- Flask (Backend Rest API)
- Angular (Frontend)
- MySQL - as persistent database

# Docker environment

For shipping and deploying the application docker-compose is used. All the configurations are in the docker-compose.yml file.

Key points of the docker-compose.yml is given below.

## services

- **backend:** runs the Flask web API.
- **db** runs the mysql database required for the backend API
- **web** this is the front-end application

## Virtual networks

One virtual network is used

- main

## list of the containers

### fruitapp-backend

This container runs under the service name backend. The dockerfile user for this container is located at `fruitapp-backend/Dockerfile`. This container is based on python:3.9 image.

### fruitapp-frontend

The frontend container for the application. The dockerfile is located at `fruitapp-frontend/.docker/dev/Dockerfile`. Base image used to build this container is `Node:14`.

### db container

The container is built using the official `mysql:5.7.22` image pulled from dockerhub.

## Preparation

To prepare the environment for the first time run the following command

```shell
bash prepare-app.sh
```

## Running

Run the app background

```shell
bash start-app.sh
```

see the logs of backend

```
docker-compose logs -f backend
```

see the logs of forntend

```
docker-compose logs -f web
```

see the logs of database

```
docker-compose logs -f db
```

## Stopping

```shell
bash stop-app.sh
```

## Removing containers

```shell
bash remove-app.sh
```
# Viewing the app

After running the app. visit [http://localhost:4200](http://localhost:4200) to view the app
