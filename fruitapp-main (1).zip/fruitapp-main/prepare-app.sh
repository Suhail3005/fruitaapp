#!/bin/bash

echo "Preparing the app.."
docker-compose build
echo "Preparation complete."