#!/bin/bash

echo "stopping the app.."
docker-compose stop
echo "App stopped"