#!/bin/bash
python manage.py db upgrade
echo "DB migration done."
python seeder.py
python main.py